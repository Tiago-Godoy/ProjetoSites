<?php

        if(isset($_POST['cadastrar'])){
                $nome = $_POST['nome'];
                $email = $_POST['email'];
                $celular = $_POST['celular'];
                $mensagem = $_POST['mensagem'];
        }

        $host = '127.0.0.1';
        //$user = 'root';
        $user = 'root';
        $senha_user = '';
        $banco = 'formcontato';
        
        $con = mysqli_connect($host, $user, $senha_user, $banco);
        
        if(!$con) {
                die("Conexão falhou" . mysqli_connect_error());
        }

        $sql = "INSERT INTO contato(Nome, Email, Celular, Mensagem) VALUES ('$nome','$email','$celular','$mensagem')";

        $rs = mysqli_query($con, $sql);

        if($rs){
                echo "Enviado com sucesso!";
        }

?>