<?php require "config.ini"; ?>

<?php

if(isset($_POST['reservar'])){

ini_set ("SMTP","sh-pro26.hostgator.com.br");

$nome = $_POST["nome"];
$celular = $_POST["celular"];
$data = $_POST["data"];
$mesa = "mesa";


if ($certo== "1"){
mail ("$emaildest","Nome: $nome\n\n 
                    Celukar: $celular\n\n 
                    Data: $data\n\n 
                    Pessoas por mesa: $mesa\n\n
                    ...::: Recebido do site CasaBonsai.com.br :::...");
}

// HTML do redirecionameto e se não redirecionar aparece um link

echo "<html><head>";

echo "<meta http-equiv=\"refresh\" content=\"0;url=$redirecionar\">";

echo "<title>Redirecionado ...</title>";

echo "</head><body bgcolor=\"#ffffff\">";

echo "<a href=\"$redirecionar\" target=\"_top\">Voltar Para O Site</a>";

echo "</body></html>";

}
?>